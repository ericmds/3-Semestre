#include <iostream>
#include <ctime>

using namespace std;

#include "Lista.h"

int main() {
    srand(time(NULL));

    Celula *listaA = NULL;
    Celula *listaB = NULL;
    Celula *listaAB = NULL;

    for (int i = 0; i < 20; i++) {
        listaA = inserir(rand()%100, listaA);
        listaB = inserir(rand()%100, listaB);
    }

    cout << "\n--- Mostrando os elementos da lista A ---\n";
    exibirLista(listaA);

    cout << "\n--- Mostrando os elementos da lista B ---\n";
    exibirLista(listaB);

    cout << "\n--- Mostrando a lista A sem os pares ---\n";
    listaA = removerPares(listaA);
    exibirLista(listaA);

    cout << "\n--- Mostrando a uniao da lista A com a lista B ---\n";
    listaAB = unirListas(listaA, listaB);
    exibirLista(listaAB);

    cout << "\n--- Mostrando a uniao da lista A e da lista B ordenada ---\n";
    ordenarLista(listaA);
    exibirLista(listaA);

    cout << "\n--- Removendo todos os elementos da uniao da lista A e Lista B ---\n";
    while(listaAB != NULL) {
        int valor = listaAB -> dado;
        listaAB = remover(valor, listaAB);
    }

    exibirLista(listaAB);

    cout <<"--- Elementos da lista removidos com sucesso ---\n";

    return 0;
}
